# OCB.GG Obsidian Glass RC16

![Installation](INSTALLATION-UEBERSICHT.svg)

1. **TeamSpeak 6 vollständig schließen**, auch unten rechts im Infobereich der Windows-Taskleiste.
2. Die heruntergeladene **ZIP-Datei vollständig entpacken** (Rechtsklick → Alle extrahieren).
3. Den **entpackten Ordner öffnen**. Nicht direkt aus der ZIP heraus installieren.
4. **`INSTALL-WINDOWS.cmd` doppelt anklicken.** Administratorrechte sind nicht erforderlich.
5. Auf die Meldung **„Installiert.“** warten. Danach eine beliebige Taste drücken, um das schwarze Fenster zu schließen. Das Theme wurde bereits vorher in den TeamSpeak-Erweiterungsordner kopiert. **Bei einer Fehlermeldung ist die Installation nicht erfolgreich abgeschlossen.**
6. Den entpackten Ordner schließen.
7. **TeamSpeak 6 starten.**
8. **Einstellungen → Erscheinungsbild → Benutzer-Theme** öffnen und den Haken bzw. Schalter aktivieren. Falls nötig, die Theme-Liste über das Aktualisieren-Symbol neu laden. Die Bezeichnungen können je nach Client-Version abweichen.
9. **OCB Obsidian Glass RC16** anklicken und aktivieren.
10. Mit eurem **OCB-TeamSpeak-Server verbinden**.
11. Sobald das Theme funktioniert, kannst du die **heruntergeladene ZIP und den entpackten Installationsordner löschen**. Die installierte Kopie bleibt in TeamSpeak erhalten. Den Ordner im TeamSpeak-Erweiterungsverzeichnis nicht löschen.

Ausführliche Hilfe: [INSTALLATION-DE.md](INSTALLATION-DE.md). Die Grafik lässt sich auch direkt im Browser öffnen.

Projekt: https://github.com/ir0CKx/OCB-TS6-THEME
