# OCB.GG Obsidian Glass RC16

TeamSpeak 6 vollständig schließen, ZIP komplett entpacken und INSTALL-WINDOWS.cmd starten. Anschließend in TeamSpeak OCB Obsidian Glass RC16 auswählen.

Der Installer prüft die Dateien, zeigt die Versionsnummern und sichert das vorhandene Theme. VERIFY-WINDOWS.cmd prüft ohne Installation. Die Änderungen stehen in CHANGELOG.md.

RC16 verändert keine Windows-Explorer-Einstellungen. Der gemeldete Explorer-Hänger ist noch nicht eindeutig geklärt.

Projekt: https://github.com/ir0CKx/OCB-TS6-THEME
